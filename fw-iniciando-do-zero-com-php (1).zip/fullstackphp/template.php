<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("CLASS_TITLE");

/*
 * 
 */
fullStackPHPClassSession("", __LINE__);